"""Compatibility wrapper for the GUI path/config helpers."""

from gui.app_paths import *  # noqa: F401,F403

