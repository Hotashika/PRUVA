import os
from PyQt5.QtWidgets import QMainWindow, QDialog, QFileDialog, QTableWidgetItem
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap
from PyQt5 import uic

try:
    from gui.veri_sistemi_njord import NjordVeriSistemi
except ImportError:
    from veri_sistemi_njord import NjordVeriSistemi

try:
    import gui.app_paths as app_paths
except ImportError:
    import app_paths as app_paths

GUI_UI_DIR = app_paths.GUI_UI_DIR
COLOR_DARK = app_paths.COLOR_DARK
COLOR_WARNING = app_paths.COLOR_WARNING
COLOR_ERROR = app_paths.COLOR_ERROR
COLOR_SUCCESS = app_paths.COLOR_SUCCESS
COLOR_INFO = app_paths.COLOR_INFO
COLOR_BLACK = app_paths.COLOR_BLACK

ALIGN_CENTER = getattr(getattr(Qt, "AlignmentFlag", None), "AlignCenter", None)
if ALIGN_CENTER is None:
    ALIGN_CENTER = getattr(Qt, "AlignCenter", 0)

class PortEkrani(QDialog):
    def __init__(self, veri_sistemi):
        super().__init__()
        uic.loadUi(str(GUI_UI_DIR.joinpath('port.ui')), self)
        self.veri_sistemi = veri_sistemi
        self.pushButton_2.clicked.connect(self.close)
        self.buttonBox.accepted.connect(self.onayla)

    def onayla(self):
        self.veri_sistemi.baglanti_kur(self.comboBox.currentText(), self.comboBox_2.currentText(), self.lineEdit.text())

class HaritaEkrani(QDialog):
    def __init__(self, veri_sistemi):
        super().__init__()
        uic.loadUi(str(GUI_UI_DIR.joinpath('map.ui')), self)
        self.veri_sistemi = veri_sistemi
        self.veri_sistemi.veri_guncelle.connect(self.guncelle)
        self.pushButton_4.clicked.connect(self.close)

    def guncelle(self, d):
        self.pushButton.setText(f"GPS: {d['gps']}")
        self.pushButton_2.setText(f"SATS: {d['gps_uydu']}")
        self.lcdNumber.display(d['mesafe'])

class GorevPlaniEkrani(QDialog):
    def __init__(self, veri_sistemi):
        super().__init__()
        uic.loadUi(str(GUI_UI_DIR.joinpath('planning.ui')), self)
        self.veri_sistemi = veri_sistemi
        self.tableWidget.setRowCount(0)
        self.pushButton_4.clicked.connect(self.close)
        self.pushButton.clicked.connect(self.dosya_sec)
        self.pushButton_2.clicked.connect(self.yukle)

    def dosya_sec(self):
        yol, _ = QFileDialog.getOpenFileName(self, "Open File", "", "TXT (*.txt)")
        if yol: 
            self.pushButton.setText(os.path.basename(yol))
            self.veri_sistemi.log_mesaj.emit(f"LOADED: {os.path.basename(yol)}")

    def yukle(self):
        pts = [("WP_01", "63.44", "10.40"), ("WP_02", "63.45", "10.41")]
        self.tableWidget.setRowCount(len(pts))
        for i, (m, lat, lon) in enumerate(pts):
            self.tableWidget.setItem(i, 0, QTableWidgetItem(m))
            self.tableWidget.setItem(i, 1, QTableWidgetItem(lat))
            self.tableWidget.setItem(i, 2, QTableWidgetItem(lon))
        self.veri_sistemi.log_mesaj.emit("WAYPOINTS UPLOADED TO VEHICLE")

class NjordAnaEkran(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi(str(GUI_UI_DIR.joinpath('njord.ui')), self)
        self.veri_sistemi = NjordVeriSistemi()
        self.veri_sistemi.veri_guncelle.connect(self.tazele)
        self.veri_sistemi.log_mesaj.connect(self.log_ekle)

        # Clear logs at start
        self.label_2.setText("")
        self.label_3.setText("")

        self.p_port = PortEkrani(self.veri_sistemi)
        self.p_harita = HaritaEkrani(self.veri_sistemi)
        self.p_plan = GorevPlaniEkrani(self.veri_sistemi)

        self.pushButton.clicked.connect(self.p_port.exec_)    
        self.pushButton_3.clicked.connect(self.p_harita.show) 
        self.pushButton_2.clicked.connect(self.p_plan.show)   
        self.pushButton_6.clicked.connect(self.icra)         
        
        # --- BUTON BAGLANTILARI ---
        self.pushButton_7.clicked.connect(self.veri_sistemi.acil_durum) # EMERGENCY STOP
        self.pushButton_4.clicked.connect(self.veri_sistemi.arm_yap)      # ARMED
        self.pushButton_8.clicked.connect(self.veri_sistemi.disarm_yap)   # DISARMED

        self.label_7.setText("LINKING CAMERA STREAM...")
        self.label_7.setStyleSheet(f"background-color: {COLOR_DARK}; color: {COLOR_WARNING}; font-weight: bold; border: 2px dashed {COLOR_WARNING};")
        self.label_7.setAlignment(ALIGN_CENTER)

        # Kamera güncelleme sinyalini bağlıyoruz
        self.veri_sistemi.kamera_guncelle.connect(self.kamera_goster)
        self._camera_auto_started = False

    def showEvent(self, event):
        super().showEvent(event)
        if not self._camera_auto_started:
            self._camera_auto_started = True
            self.veri_sistemi.kamera_oto_baslat()

    # --- HİZALAMA HATASI BURADA DÜZELTİLDİ ---
    def tazele(self, d):
        # YAW, ROLL ve PITCH değerlerinin ekrana basıldığı kısımlar
        self.pushButton_10.setText(f"YAW: {d['yaw']:.1f}°")
        self.pushButton_5.setText(f"ROLL: {d['roll']:.1f}°")
        self.pushButton_9.setText(f"PITCH: {d['pitch']:.1f}°")
        
        self.lcdNumber_3.display(d['hiz'])
        self.pushButton_11.setText(str(d['lat']))
        self.pushButton_12.setText(str(d['lon']))
        self.progressBar.setValue(d['pil_yuzde'])
        self.lcdNumber.display(d['akim'])
        self.lcdNumber_2.display(d['voltaj'])
        
        # Dinamik Karar Mantığı Metni
        self.textEdit.setPlainText(d['decision_log'])

    # Kameradan gelen görüntüyü ekrana (label_7) basan yeni fonksiyon
    def kamera_goster(self, image):
        if image is None:
            return

        pixmap = QPixmap.fromImage(image)
        self.label_7.setText("")
        self.label_7.setStyleSheet(f"background-color: {COLOR_BLACK};")
        self.label_7.setScaledContents(False)

        hedef_boyut = self.label_7.size()
        if hedef_boyut.width() > 0 and hedef_boyut.height() > 0:
            pixmap = pixmap.scaled(
                hedef_boyut,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )

        self.label_7.setPixmap(pixmap)
        self.label_7.setAlignment(ALIGN_CENTER)

    def log_ekle(self, m):
        self.label_3.setText(self.label_2.text())
        self.label_2.setText(f">> {m}")
        
        if "!!!" in m or "ERROR" in m:
            self.label_2.setStyleSheet(f"color: {COLOR_ERROR}; font-weight: bold;")
        elif "COMPLETED" in m or "SUCCESS" in m:
            self.label_2.setStyleSheet(f"color: {COLOR_SUCCESS}; font-weight: bold;")
        else:
            self.label_2.setStyleSheet(f"color: {COLOR_INFO}; font-weight: bold;")

    def icra(self):
        s = "M1"
        if self.radioButton_2.isChecked(): s = "M2"
        elif self.radioButton_3.isChecked(): s = "M3"
        elif self.radioButton_4.isChecked(): s = "M4"
        self.veri_sistemi.gorev_baslat(s)