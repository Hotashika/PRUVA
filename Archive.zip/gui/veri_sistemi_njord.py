import time
import math
import copy
from threading import Thread, Lock
from PyQt5.QtCore import QObject, pyqtSignal
from PyQt5.QtGui import QImage
from pymavlink import mavutil

import importlib.util
import sys

try:
    from gui.app_paths import (
        HEARTBEAT_TIMEOUT, ARDUROVER_MODS, get_grap_video_path,
    )
except ImportError:
    from app_paths import (
        HEARTBEAT_TIMEOUT, ARDUROVER_MODS, get_grap_video_path,
    )

# Try the normal package import first; if it fails, try to dynamically load
# `grap_video.py` from repository locations (Fetch Data / fetch_data / Fetch_Data).
try:
    import importlib as _importlib
    client_side = _importlib.import_module('zed.task1.client_side')
    # prefer an attribute `grap_video` if the package exposes it, otherwise
    # assume the module itself provides the needed API
    grap_video = getattr(client_side, 'grap_video', client_side)
except Exception:
    grap_video = None
    grap_video_path = get_grap_video_path()
    if grap_video_path:
        spec = importlib.util.spec_from_file_location("grap_video", str(grap_video_path))
        if spec:
            module = importlib.util.module_from_spec(spec)
            # make the module available under a stable name
            sys.modules["grap_video"] = module
            spec.loader.exec_module(module)  # type: ignore
            grap_video = module
    if grap_video is None:
        raise ImportError(
            "Cannot import grap_video. Tried package 'zed.task1.client_side' and get_grap_video_path()."
        )

# Use the package import (clean layout). If this fails, the developer can
# re-enable the legacy path loader manually. For now prefer the package style.


# ─────────────────────────────────────────────
#  Veri Sistemi Sınıfı
# ─────────────────────────────────────────────


class NjordVeriSistemi(QObject):
    """
    Pixhawk MAVLink telemetrisi + USB kamera yönetimi.

    Sinyal / İş Parçacığı Mimarisi
    ───────────────────────────────
    • veri_guncelle   → arayüze kopyalanmış durum sözlüğü
    • log_mesaj       → zaman damgalı log satırı
    • kamera_guncelle → QImage kare
    • baglanti_kesildi → heartbeat timeout → UI ikaz
    """

    veri_guncelle    = pyqtSignal(dict)
    log_mesaj        = pyqtSignal(str)
    kamera_guncelle  = pyqtSignal(QImage)
    baglanti_kesildi = pyqtSignal()          # Link-lost sinyali

    # ──────────────────────────────
    #  Başlangıç
    # ──────────────────────────────
    def __init__(self):
        super().__init__()

        # Paylaşılan durum sözlüğü — sadece _lock altında yazılır
        self._durum = {
            "roll": 0.0, "pitch": 0.0, "yaw": 0.0,
            "lat": 0.0,  "lon": 0.0,   "hiz": 0.0,
            "voltaj": 0.0, "akim": 0.0, "pil_yuzde": 0,
            "gps": "NO FIX", "gps_uydu": 0, "mesafe": 0.0,
            "mod": "UNKNOWN",
            "mod_id": -1,
            "active_mission": None,
            "armed": False,
            "link_ok": False,
            "decision_log": "SYSTEM STANDBY | READY TO CONNECT",
        }
        self._lock       = Lock()
        self.connection  = None
        self.is_running  = False
        self._last_hb    = None   # Son heartbeat zamanı
        self._camera_started = False
        self._camera_running = False

    # ──────────────────────────────
    #  Yardımcı — güvenli durum yazma
    # ──────────────────────────────
    def _set(self, **kwargs):
        """Lock altında birden fazla anahtarı tek seferde günceller."""
        with self._lock:
            self._durum.update(kwargs)

    def _snapshot(self) -> dict:
        """Lock altında derin kopyalı anlık görüntü döndürür."""
        with self._lock:
            return copy.deepcopy(self._durum)

    def _emit_durum(self):
        """Anlık görüntüyü sinyal olarak fırlatır."""
        self.veri_guncelle.emit(self._snapshot())

    def _log(self, mesaj: str):
        self.log_mesaj.emit(mesaj)

    # ──────────────────────────────
    #  Bağlantı Kurma
    # ──────────────────────────────
    def baglanti_kur(self, tip: str, baud: str, port: str):
        """Arayüzden gelen parametrelerle Pixhawk + Kamera bağlantılarını başlatır."""
        self._log(f"INITIATING {tip} CONNECTION → {port}")

        try:
            if tip == "UDP":
                address = f"udp:{port}" if ":" in port else f"udp:127.0.0.1:{port}"
                self.connection = mavutil.mavlink_connection(address)
            else:
                self.connection = mavutil.mavlink_connection(port, baud=int(baud))

            self._log("Waiting for Pixhawk heartbeat…")
            self.is_running = True

            # İş parçacıkları — daemon=True → ana program kapanınca kendiliğinden biter
            Thread(target=self._mavlink_dongusu, daemon=True, name="MAVLink").start()
            self._kamera_baslat()

        except Exception as exc:
            self._log(f"CONNECTION ERROR: {exc}")

    def baglanti_kes(self):
        """Tüm iş parçacıklarını durdurur ve bağlantıyı kapatır."""
        self.is_running = False
        self._camera_running = False
        self._camera_started = False
        if self.connection:
            try:
                self.connection.close()
            except Exception:
                pass
            self.connection = None
        self._set(link_ok=False, mod="UNKNOWN", mod_id=-1, armed=False,
                  decision_log="DISCONNECTED")
        self._emit_durum()
        self._log("CONNECTION CLOSED")

    def kamera_oto_baslat(self):
        """GUI açılır açılmaz Jetson kamerasına bağlanmayı dener."""
        if self._camera_started:
            return
        self._kamera_baslat()

    def _kamera_baslat(self):
        if self._camera_started:
            return
        self._camera_started = True
        self._camera_running = True
        Thread(target=self._kamera_dongusu, daemon=True, name="Camera").start()

    # ──────────────────────────────
    #  Kamera İş Parçacığı
    # ──────────────────────────────
    def _kamera_dongusu(self):
        """Jetson üzerindeki ZED stream'ini alıp QImage olarak fırlatır."""
        try:
            grap_video.start(
                frame_callback=self.kamera_guncelle.emit,
                log_callback=self._log,
                stop_callback=lambda: self._camera_running,
            )
        except Exception as exc:
            self._log(f"CAMERA THREAD ERROR: {exc}")
        finally:
            self._log("CAMERA OFFLINE")

    # ──────────────────────────────
    #  MAVLink İş Parçacığı
    # ──────────────────────────────
    def _mavlink_dongusu(self):
        """Pixhawk tamponunu asenkron boşaltır; heartbeat ile mod + arm takibi yapar."""
        try:
            self.connection.wait_heartbeat()
            self._last_hb = time.time()
            self._log(f"CONNECTED! System ID: {self.connection.target_system}")
            self._set(link_ok=True, decision_log="CONNECTED TO PIXHAWK | RECEIVING DATA")
            self._emit_durum()

            # Veri akışı istekleri
            self._request_stream(mavutil.mavlink.MAV_DATA_STREAM_ALL,    10)
            self._request_stream(mavutil.mavlink.MAV_DATA_STREAM_EXTRA1, 20)

            son_ui_guncelleme = time.time()

            while self.is_running:
                msg = self.connection.recv_match(blocking=False)

                if msg:
                    self._islenmis_mesaj(msg)

                # ── Link-lost kontrolü ──────────────────────────
                if self._last_hb and (time.time() - self._last_hb) > HEARTBEAT_TIMEOUT:
                    self._set(link_ok=False,
                              decision_log=f"LINK LOST! No heartbeat for {HEARTBEAT_TIMEOUT:.0f}s")
                    self._log("WARNING: HEARTBEAT TIMEOUT — LINK LOST")
                    self.baglanti_kesildi.emit()
                    self._last_hb = None   # Bir kez tetikle

                # ── Arayüz güncelleme hızı (20 Hz) ────────────
                now = time.time()
                if now - son_ui_guncelleme > 0.05:
                    self._emit_durum()
                    son_ui_guncelleme = now

                time.sleep(0.001)

        except Exception as exc:
            self._log(f"MAVLINK THREAD ERROR: {exc}")
            self.is_running = False

    def _request_stream(self, stream_id: int, rate: int):
        self.connection.mav.request_data_stream_send(
            self.connection.target_system,
            self.connection.target_component,
            stream_id, rate, 1
        )

    def _islenmis_mesaj(self, msg):
        """Gelen MAVLink mesajını çözümleyip _durum sözlüğünü günceller."""
        msg_type = msg.get_type()

        # ── HEARTBEAT → mod + armed (Pixhawk'tan gerçek değer) ──
        if msg_type == "HEARTBEAT":
            self._last_hb = time.time()
            armed    = bool(msg.base_mode & mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED)
            mod_id   = int(msg.custom_mode)
            mod_name = ARDUROVER_MODS.get(mod_id, f"MODE_{mod_id}")
            self._set(armed=armed, mod_id=mod_id, mod=mod_name, link_ok=True)

        elif msg_type == "VFR_HUD":
            self._set(yaw=msg.heading, hiz=msg.groundspeed)

        elif msg_type == "ATTITUDE":
            self._set(
                roll=math.degrees(msg.roll),
                pitch=math.degrees(msg.pitch),
            )

        elif msg_type == "NAV_CONTROLLER_OUTPUT":
            self._set(mesafe=msg.wp_dist)

        elif msg_type == "GLOBAL_POSITION_INT":
            self._set(lat=msg.lat / 1e7, lon=msg.lon / 1e7)

        elif msg_type == "SYS_STATUS":
            self._set(
                voltaj=msg.voltage_battery / 1000.0,
                akim=msg.current_battery / 100.0,
                pil_yuzde=msg.battery_remaining,
            )

        elif msg_type == "GPS_RAW_INT":
            self._set(
                gps_uydu=msg.satellites_visible,
                gps="FIX" if msg.fix_type >= 3 else "NO FIX",
            )

    # ──────────────────────────────
    #  Komut Metodları  (Modüler)
    # ──────────────────────────────
    def _komut_gonder(self, command, *params):
        """MAV_CMD_* komutlarını güvenli biçimde gönderir."""
        if not self.connection:
            self._log("ERROR: No active connection")
            return False
        # params listesini 7 elemana tamamla
        p = list(params) + [0] * (7 - len(params))
        self.connection.mav.command_long_send(
            self.connection.target_system,
            self.connection.target_component,
            command, 0,
            p[0], p[1], p[2], p[3], p[4], p[5], p[6]
        )
        return True

    def arm_yap(self):
        """Motoru çalıştırır (ARM). Gerçek onay HEARTBEAT'ten gelir."""
        with self._lock:
            if self._durum["mod"] == "EMERGENCY":
                self._log("ERROR: RESET EMERGENCY BEFORE ARM")
                return
            if self._durum["armed"]:
                self._log("INFO: Already armed")
                return

        if self._komut_gonder(mavutil.mavlink.MAV_CMD_COMPONENT_ARM_DISARM, 1):
            self._set(decision_log="ARM COMMAND SENT | Waiting Pixhawk confirm…")
            self._log("ARM COMMAND SENT → waiting HEARTBEAT confirm")
            self._emit_durum()

    def disarm_yap(self):
        """Motorları kilitler (DISARM). Gerçek onay HEARTBEAT'ten gelir."""
        if self._komut_gonder(mavutil.mavlink.MAV_CMD_COMPONENT_ARM_DISARM, 0):
            self._set(
                hiz=0.0,
                decision_log="DISARM COMMAND SENT | Waiting Pixhawk confirm…",
            )
            self._log("DISARM COMMAND SENT → waiting HEARTBEAT confirm")
            self._emit_durum()

    def mod_ayarla(self, mod_id: int):
        """Verilen mod_id'ye geçiş komutu gönderir. Onay HEARTBEAT'ten gelir."""
        mod_name = ARDUROVER_MODS.get(mod_id, f"MODE_{mod_id}")
        if not self.connection:
            self._log("ERROR: No connection for mode change")
            return
        self.connection.mav.set_mode_send(
            self.connection.target_system,
            mavutil.mavlink.MAV_MODE_FLAG_CUSTOM_MODE_ENABLED,
            mod_id
        )
        self._set(decision_log=f"MODE CMD SENT: {mod_name} | Waiting confirm…")
        self._log(f"MODE COMMAND SENT: {mod_name} ({mod_id})")
        self._emit_durum()

    def gorev_baslat(self, gorev_adi: str):
        """AUTO moduna geçer ve görevi başlatır."""
        with self._lock:
            armed = self._durum["armed"]
        if not armed:
            self._log("ERROR: ARM VEHICLE TO START MISSION")
            return
        self.mod_ayarla(10)  # AUTO
        self._set(active_mission=gorev_adi,
                  decision_log=f"MISSION STARTED: {gorev_adi} | CMD: AUTO")
        self._log(f"MISSION STARTED: {gorev_adi}")
        self._emit_durum()

    def acil_durum(self):
        """Sistemi acil olarak durdurur (DISARM + EMERGENCY bayrağı)."""
        self._set(mod="EMERGENCY",
                  decision_log="!!! EMERGENCY STOP ACTIVATED !!!")
        self._log("!!! EMERGENCY STOP !!!")
        self.disarm_yap()

    # ──────────────────────────────
    #  Durum Okuma (Thread-safe)
    # ──────────────────────────────
    def durum_al(self) -> dict:
        """Mevcut durumun derin kopyasını döndürür (harici sorgulama için)."""
        return self._snapshot()



