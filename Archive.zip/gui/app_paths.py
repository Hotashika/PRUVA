from __future__ import annotations

from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
GUI_DIR = PROJECT_ROOT / "gui"
GUI_UI_DIR = GUI_DIR / "ui"
GUI_IMAGES_DIR = GUI_DIR / "images"
FETCH_DATA_DIR = PROJECT_ROOT / "Fetch Data"

COLOR_DARK = "#1f232a"
COLOR_WARNING = "#f0ad4e"
COLOR_ERROR = "#d9534f"
COLOR_SUCCESS = "#5cb85c"
COLOR_INFO = "#5bc0de"
COLOR_BLACK = "#000000"

HEARTBEAT_TIMEOUT = 10.0

# ArduRover custom mode ids used by the UI / telemetry layer.
ARDUROVER_MODS = {
    0: "MANUAL",
    2: "LEARNING",
    3: "STEERING",
    4: "HOLD",
    5: "LOITER",
    6: "FOLLOW",
    7: "SIMPLE",
    10: "AUTO",
    11: "RTL",
    12: "SMART_RTL",
    15: "GUIDED",
}


def get_grap_video_path() -> Path | None:
    """Return the legacy `grap_video.py` path if it exists in the repository."""
    candidates = [
        FETCH_DATA_DIR / "grap_video.py",
        PROJECT_ROOT / "fetch_data" / "grap_video.py",
        PROJECT_ROOT / "Fetch_Data" / "grap_video.py",
        PROJECT_ROOT / "grap_video.py",
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None

